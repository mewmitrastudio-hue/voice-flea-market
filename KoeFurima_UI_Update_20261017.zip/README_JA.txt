声のフリマ 修正版 2026.10.17-1

このZIP内のindex.htmlが修正版です。旧版のindexファイルを代わりに使わないでください。
既存GitHubリポジトリ mewmitrastudio-hue/voice-flea-market の同じパスに反映します。
ZIPそのものをリポジトリへ置くだけでは反映されません。
package.json、package-lock.json、release-manifest.jsonとscriptsフォルダーも同じ構成で更新します。
WEB公開後に更新番号、ホーム、メニュー、出品、依頼、メッセージ、マイページを確認します。
iOSはCI_BUILD_NUMBERを既存より大きくしてcapawesome:buildを実行し、新しいビルドを配信します。
本番画面とTestFlightへは未反映です。新しい見た目の実機確認は未完了です。
既存テスト39件は成功。WEBソースとiOS同梱HTMLの一致は検証済みです。
支払い環境・アプリアイコン・ストア審査上の残課題はこのUI変更では解決していません。
